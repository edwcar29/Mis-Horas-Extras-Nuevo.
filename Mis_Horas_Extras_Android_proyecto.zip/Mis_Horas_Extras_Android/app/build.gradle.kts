plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.mishorasextras"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.mishorasextras"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
