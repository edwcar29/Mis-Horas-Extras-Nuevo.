package com.example.mishorasextras

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var date: EditText
    private lateinit var start: EditText
    private lateinit var end: EditText
    private lateinit var holiday: CheckBox
    private lateinit var h50: TextView
    private lateinit var h100: TextView
    private lateinit var summary: TextView
    private var total50 = 0.0
    private var total100 = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.WHITE)
        }
        fun label(s: String) = TextView(this).apply {
            text = s; textSize = 16f; setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 4)
        }
        fun field(value: String, hint: String): EditText = EditText(this).apply {
            setText(value); this.hint = hint; textSize = 17f
        }
        root.addView(TextView(this).apply {
            text = "Mis Horas Extras"; textSize = 25f; setTextColor(Color.rgb(30,70,150))
        })
        root.addView(label("Fecha (AAAA-MM-DD)"))
        date = field(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()), "2026-01-01")
        root.addView(date)
        root.addView(label("Hora de entrada (HH:mm)"))
        start = field("08:30", "08:30"); root.addView(start)
        root.addView(label("Hora de salida (HH:mm)"))
        end = field("19:30", "19:30"); root.addView(end)
        holiday = CheckBox(this).apply { text = "Feriado o descanso obligatorio" }
        root.addView(holiday)
        h50 = TextView(this).apply { textSize = 20f; setTextColor(Color.rgb(22,101,52)) }
        h100 = TextView(this).apply { textSize = 20f; setTextColor(Color.rgb(29,78,216)) }
        root.addView(h50); root.addView(h100)
        val calc = Button(this).apply { text = "Calcular horas" }
        root.addView(calc)
        val save = Button(this).apply { text = "Agregar al resumen mensual" }
        root.addView(save)
        summary = TextView(this).apply { textSize = 18f; setPadding(0,18,0,0); setTextColor(Color.DKGRAY) }
        root.addView(summary)
        calc.setOnClickListener { calculate() }
        save.setOnClickListener {
            calculate()
            val a = h50.text.toString().substringAfter(": ").toDoubleOrNull() ?: 0.0
            val b = h100.text.toString().substringAfter(": ").toDoubleOrNull() ?: 0.0
            total50 += a; total100 += b
            summary.text = "Resumen acumulado\n50%: %.2f h\n100%: %.2f h\nTotal: %.2f h".format(total50,total100,total50+total100)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        calculate()
    }

    private fun calculate() {
        try {
            val dateObj = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date.text.toString())!!
            val cal = Calendar.getInstance().apply { time = dateObj }
            val day = cal.get(Calendar.DAY_OF_WEEK)
            val all100 = holiday.isChecked || day == Calendar.SATURDAY || day == Calendar.SUNDAY
            val s = start.text.toString().split(":")
            val e = end.text.toString().split(":")
            var from = s[0].toInt()*60 + s[1].toInt()
            var to = e[0].toInt()*60 + e[1].toInt()
            if (to <= from) to += 1440
            var a = 0; var b = 0
            for (m in from until to) {
                val minute = m % 1440
                if (all100 || minute < 360) b++ else if (minute >= 1050) a++
            }
            h50.text = "Horas al 50%: %.2f".format(a / 60.0)
            h100.text = "Horas al 100%: %.2f".format(b / 60.0)
        } catch (_: Exception) {
            h50.text = "Revisa fecha y horas"; h100.text = ""
        }
    }
}
