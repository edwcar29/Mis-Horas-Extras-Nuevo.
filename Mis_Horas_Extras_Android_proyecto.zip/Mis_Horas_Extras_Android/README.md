# Mis Horas Extras

Proyecto Android Kotlin. Módulo de aplicación ubicado en `app/`.

Compilación en GitHub Actions: ejecutar `./gradlew assembleDebug` cuando se incluya Gradle Wrapper o usar la distribución Gradle instalada en el runner.
