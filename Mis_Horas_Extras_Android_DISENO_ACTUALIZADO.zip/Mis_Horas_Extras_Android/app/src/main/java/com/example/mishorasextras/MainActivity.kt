package com.example.mishorasextras

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var dateBtn: Button
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private lateinit var typeSpinner: Spinner
    private lateinit var notes: EditText
    private lateinit var preview50: TextView
    private lateinit var preview100: TextView
    private lateinit var totalHours: TextView
    private lateinit var summary: TextView
    private lateinit var history: LinearLayout
    private lateinit var saveBtn: Button
    private var selectedDate = Calendar.getInstance()
    private var startMinutes = 8 * 60 + 30
    private var endMinutes = 17 * 60 + 30
    private val entries = mutableListOf<JSONObject>()
    private val typeOptions = arrayOf("Día laboral", "Sábado", "Domingo", "Feriado", "Descanso obligatorio")
    private val navy = Color.rgb(20, 37, 75)
    private val blue = Color.rgb(42, 91, 210)
    private val green = Color.rgb(19, 139, 91)
    private val orange = Color.rgb(235, 139, 40)
    private val bg = Color.rgb(245, 247, 251)
    private val textDark = Color.rgb(36, 46, 66)
    private val muted = Color.rgb(111, 123, 144)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadEntries()
        buildScreen()
        updatePreview()
        updateSummary()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(28))
        }
        scroll.addView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(navy, 22)
        }
        header.addView(label("CONTROL DE JORNADA", 11f, Color.rgb(185, 204, 255), true))
        header.addView(label("Mis Horas Extras", 27f, Color.WHITE, true).apply { setPadding(0, dp(5), 0, dp(4)) })
        header.addView(label("Calcula, registra y revisa tus horas por porcentaje.", 14f, Color.rgb(228, 235, 250), false))
        root.addView(header)

        root.addView(sectionTitle("Registrar jornada", "Completa los datos del día"))
        val form = card()
        currentForm = form
        fieldLabel("FECHA")
        dateBtn = actionButton(dateString(), Color.rgb(235, 241, 255), blue)
        dateBtn.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        dateBtn.setOnClickListener { showDatePicker() }
        form.addView(dateBtn, matchWrap())
        fieldLabel("TIPO DE DÍA")
        typeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, typeOptions)
            setSelection(0)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { updatePreview() }
            }
        }
        form.addView(typeSpinner, matchWrap())
        fieldLabel("HORARIO")
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; }
        startBtn = actionButton(timeString(startMinutes), Color.rgb(235, 241, 255), blue)
        endBtn = actionButton(timeString(endMinutes), Color.rgb(235, 241, 255), blue)
        startBtn.setOnClickListener { showTimePicker(true) }
        endBtn.setOnClickListener { showTimePicker(false) }
        val dash = label(" — ", 18f, muted, true).apply { gravity = Gravity.CENTER }
        times.addView(startBtn, LinearLayout.LayoutParams(0, dp(48), 1f))
        times.addView(dash)
        times.addView(endBtn, LinearLayout.LayoutParams(0, dp(48), 1f))
        form.addView(times)
        fieldLabel("NOTA (OPCIONAL)")
        notes = EditText(this).apply {
            hint = "Ej. turno extendido, apoyo…"
            textSize = 14f
            minLines = 2
            gravity = Gravity.TOP
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(248, 250, 253), 12, Color.rgb(222, 228, 239))
        }
        form.addView(notes, matchWrap())
        root.addView(form)

        root.addView(sectionTitle("Vista previa", "El resultado se actualiza al cambiar los datos"))
        val resultRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val card50 = resultCard("HORAS AL 50%", green)
        preview50 = card50.second
        val card100 = resultCard("HORAS AL 100%", blue)
        preview100 = card100.second
        resultRow.addView(card50.first, LinearLayout.LayoutParams(0, dp(116), 1f).apply { marginEnd = dp(8) })
        resultRow.addView(card100.first, LinearLayout.LayoutParams(0, dp(116), 1f).apply { marginStart = dp(8) })
        root.addView(resultRow)
        val totalCard = card().apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(label("TOTAL DE HORAS", 13f, muted, true), LinearLayout.LayoutParams(0, dp(46), 1f))
            totalHours = label("0.00 h", 23f, navy, true)
            addView(totalHours)
        }
        root.addView(totalCard)

        saveBtn = primaryButton("＋  Guardar jornada")
        saveBtn.setOnClickListener { saveEntry() }
        root.addView(saveBtn, matchWrap())
        val reset = actionButton("Limpiar nota", Color.WHITE, muted)
        reset.setOnClickListener { notes.setText("") }
        root.addView(reset, matchWrap())

        root.addView(sectionTitle("Resumen mensual", "Acumulado de los registros guardados"))
        val summaryCard = card()
        summary = label("Todavía no hay jornadas guardadas.", 15f, textDark, false)
        summaryCard.addView(summary)
        val export = actionButton("Compartir resumen CSV", Color.rgb(235, 241, 255), blue)
        export.setOnClickListener { shareCsv() }
        summaryCard.addView(export, matchWrap())
        root.addView(summaryCard)

        root.addView(sectionTitle("Historial", "Jornadas registradas en este dispositivo"))
        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(history)
        setContentView(scroll)
    }

    private fun sectionTitle(title: String, sub: String): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(22), 0, dp(10)) }
        col.addView(label(title, 19f, navy, true))
        col.addView(label(sub, 12f, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        return col
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(Color.WHITE, 18, Color.rgb(230, 234, 242))
        elevation = dp(2).toFloat()
    }

    private fun resultCard(title: String, color: Int): Pair<LinearLayout, TextView> {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(14), dp(10), dp(14))
            background = rounded(Color.WHITE, 18, color)
        }
        c.addView(label(title, 11f, color, true).apply { gravity = Gravity.CENTER })
        val value = label("0.00 h", 27f, color, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        c.addView(value)
        c.addView(label("calculadas", 11f, muted, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0) })
        return Pair(c, value)
    }

    private fun fieldLabel(s: String) {
        val t = label(s, 11f, muted, true)
        t.setPadding(0, dp(14), 0, dp(6))
        (currentForm ?: return).addView(t)
    }
    private var currentForm: LinearLayout? = null

    private fun label(s: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun actionButton(s: String, fill: Int, color: Int): Button = Button(this).apply {
        text = s; textSize = 14f; setTextColor(color); isAllCaps = false
        background = rounded(fill, 12, if (fill == Color.WHITE) Color.rgb(224, 230, 240) else fill)
        minHeight = dp(46)
        setPadding(dp(12), dp(4), dp(12), dp(4))
    }

    private fun primaryButton(s: String): Button = Button(this).apply {
        text = s; textSize = 15f; setTextColor(Color.WHITE); isAllCaps = false
        background = rounded(blue, 14)
        minHeight = dp(54)
        setTypeface(null, Typeface.BOLD)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null && stroke != color) setStroke(dp(1), stroke)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showDatePicker() {
        DatePickerDialog(this, { _, y, m, d ->
            selectedDate.set(y, m, d)
            dateBtn.text = dateString()
            updatePreview()
        }, selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH), selectedDate.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun showTimePicker(isStart: Boolean) {
        val mins = if (isStart) startMinutes else endMinutes
        TimePickerDialog(this, { _, hour, minute ->
            if (isStart) startMinutes = hour * 60 + minute else endMinutes = hour * 60 + minute
            if (isStart) startBtn.text = timeString(startMinutes) else endBtn.text = timeString(endMinutes)
            updatePreview()
        }, mins / 60, mins % 60, true).show()
    }

    private fun dayType(): String {
        val picked = typeSpinner.selectedItem?.toString() ?: "Día laboral"
        val day = selectedDate.get(Calendar.DAY_OF_WEEK)
        if (picked == "Día laboral" && day == Calendar.SATURDAY) return "Sábado"
        if (picked == "Día laboral" && day == Calendar.SUNDAY) return "Domingo"
        return picked
    }

    private fun calculate(): Pair<Double, Double> {
        var from = startMinutes
        var to = endMinutes
        if (to <= from) to += 1440
        val type = dayType()
        val all100 = type == "Sábado" || type == "Domingo" || type == "Feriado" || type == "Descanso obligatorio"
        var h50 = 0
        var h100 = 0
        for (m in from until to) {
            val minute = m % 1440
            if (all100 || minute < 360) h100++
            else if (minute >= 1050) h50++
        }
        return Pair(h50 / 60.0, h100 / 60.0)
    }

    private fun updatePreview() {
        if (!::preview50.isInitialized) return
        val (a, b) = calculate()
        preview50.text = "%.2f h".format(Locale.US, a)
        preview100.text = "%.2f h".format(Locale.US, b)
        totalHours.text = "%.2f h".format(Locale.US, a + b)
    }

    private fun saveEntry() {
        val (a, b) = calculate()
        if (a + b <= 0.0) {
            Toast.makeText(this, "No hay horas calculadas en este horario. Revisa la hora de salida.", Toast.LENGTH_LONG).show()
            return
        }
        val item = JSONObject().apply {
            put("date", dateString())
            put("type", dayType())
            put("start", timeString(startMinutes))
            put("end", timeString(endMinutes))
            put("h50", a)
            put("h100", b)
            put("notes", notes.text.toString())
        }
        entries.add(0, item)
        persistEntries()
        updateSummary()
        updateHistory()
        Toast.makeText(this, "Jornada guardada", Toast.LENGTH_SHORT).show()
    }

    private fun updateSummary() {
        if (!::summary.isInitialized) return
        val month = SimpleDateFormat("yyyy-MM", Locale.US).format(selectedDate.time)
        var a = 0.0; var b = 0.0; var count = 0
        entries.forEach {
            if (it.optString("date").startsWith(month)) {
                a += it.optDouble("h50"); b += it.optDouble("h100"); count++
            }
        }
        summary.text = "Mes: $month\nJornadas: $count\n\n50%     %.2f h\n100%   %.2f h\nTOTAL  %.2f h".format(Locale.US, a, b, a + b)
        updateHistory()
    }

    private fun updateHistory() {
        if (!::history.isInitialized) return
        history.removeAllViews()
        if (entries.isEmpty()) {
            history.addView(card().apply { addView(label("No hay registros todavía. Guarda una jornada para verla aquí.", 14f, muted, false)) })
            return
        }
        entries.take(30).forEachIndexed { index, item ->
            val c = card()
            val heading = label("${item.optString("date")}  •  ${item.optString("type")}", 14f, navy, true)
            c.addView(heading)
            c.addView(label("${item.optString("start")}–${item.optString("end")}     50%: %.2f h     100%: %.2f h".format(Locale.US, item.optDouble("h50"), item.optDouble("h100")), 12f, textDark, false).apply { setPadding(0, dp(6), 0, 0) })
            val note = item.optString("notes")
            if (note.isNotBlank()) c.addView(label(note, 12f, muted, false).apply { setPadding(0, dp(4), 0, 0) })
            val del = actionButton("Eliminar registro", Color.rgb(255, 241, 242), Color.rgb(190, 50, 65))
            del.setOnClickListener {
                entries.removeAt(index)
                persistEntries(); updateSummary()
            }
            c.addView(del, matchWrap())
            val lp = matchWrap().apply { bottomMargin = dp(9) }
            history.addView(c, lp)
        }
    }

    private fun loadEntries() {
        val raw = getSharedPreferences("overtime", MODE_PRIVATE).getString("entries", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) entries.add(arr.getJSONObject(i))
        } catch (_: Exception) {}
    }

    private fun persistEntries() {
        val arr = JSONArray()
        entries.forEach { arr.put(it) }
        getSharedPreferences("overtime", MODE_PRIVATE).edit().putString("entries", arr.toString()).apply()
    }

    private fun shareCsv() {
        val month = SimpleDateFormat("yyyy-MM", Locale.US).format(selectedDate.time)
        val csv = StringBuilder("Fecha,Tipo,Entrada,Salida,Horas 50%,Horas 100%,Nota\n")
        entries.filter { it.optString("date").startsWith(month) }.forEach {
            val note = it.optString("notes").replace("\"", "\"\"")
            csv.append("${it.optString("date")},${it.optString("type")},${it.optString("start")},${it.optString("end")},${it.optDouble("h50")},${it.optDouble("h100")},\"$note\"\n")
        }
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Mis horas extras $month")
            putExtra(android.content.Intent.EXTRA_TEXT, csv.toString())
        }
        startActivity(android.content.Intent.createChooser(intent, "Compartir CSV"))
    }

    private fun dateString() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(selectedDate.time)
    private fun timeString(minutes: Int) = "%02d:%02d".format(Locale.US, (minutes / 60) % 24, minutes % 60)
}
