# Mis Horas Extras — Proyecto Android actualizado

La pantalla principal fue rediseñada con encabezado, formulario de jornada, selectores de fecha/hora, tarjetas de vista previa al 50% y 100%, total de horas, resumen mensual, historial local y compartir CSV.

Reglas: jornada de lunes a viernes desde las 17:30 se considera al 50%; tramo 00:00–06:00 se considera al 100%; sábado, domingo, feriado y descanso obligatorio al 100%. Los registros quedan guardados localmente.

Abrir en Android Studio y compilar con SDK 35 y Java 17. Workflow GitHub Actions puede compilar el APK.
