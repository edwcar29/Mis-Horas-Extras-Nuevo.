package com.example.mishorasextras

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val navy = Color.rgb(20, 42, 82)
    private val blue = Color.rgb(37, 99, 235)
    private val green = Color.rgb(22, 163, 74)
    private val paleBlue = Color.rgb(239, 246, 255)
    private val paleGreen = Color.rgb(240, 253, 244)
    private val ink = Color.rgb(31, 41, 55)
    private val muted = Color.rgb(107, 114, 128)
    private lateinit var dateField: TextView
    private lateinit var startField: TextView
    private lateinit var endField: TextView
    private lateinit var weekday: TextView
    private lateinit var holiday: CheckBox
    private lateinit var notes: EditText
    private lateinit var preview50: TextView
    private lateinit var preview100: TextView
    private lateinit var totalPreview: TextView
    private lateinit var monthSummary: TextView
    private lateinit var history: LinearLayout
    private var savedRecords = JSONArray()
    private var current50 = 0.0
    private var current100 = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedRecords = try { JSONArray(getPreferences(0).getString("records", "[]")) } catch (_: Exception) { JSONArray() }
        buildScreen()
        updateDay()
        calculate()
        refreshMonth()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(246, 248, 252)) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(24)) }
        scroll.addView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(22));
            background = rounded(navy, 22)
        }
        header.addView(TextView(this).apply { text = "MIS HORAS EXTRAS"; textSize = 24f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        header.addView(TextView(this).apply { text = "Control claro de tus horas y porcentajes"; textSize = 14f; setTextColor(Color.rgb(219, 234, 254)); setPadding(0, dp(6), 0, 0) })
        root.addView(header)
        root.addView(sectionTitle("REGISTRO DE JORNADA"))

        val dateRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val dateCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        dateCol.addView(fieldLabel("Fecha"))
        dateField = pickerField(today(), "Elegir fecha")
        dateCol.addView(dateField)
        dateRow.addView(dateCol)
        val dayCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END; layoutParams = LinearLayout.LayoutParams(0, -2, 1f); setPadding(dp(10), 0, 0, 0) }
        dayCol.addView(fieldLabel("Día de la semana"))
        weekday = TextView(this).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(navy); gravity = Gravity.END; setPadding(0, dp(13), 0, dp(13)) }
        dayCol.addView(weekday)
        dateRow.addView(dayCol)
        root.addView(dateRow)

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val startCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        startCol.addView(fieldLabel("Hora de entrada")); startField = pickerField("08:30", "Entrada"); startCol.addView(startField)
        val endCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f); setPadding(dp(10), 0, 0, 0) }
        endCol.addView(fieldLabel("Hora de salida")); endField = pickerField("19:30", "Salida"); endCol.addView(endField)
        timeRow.addView(startCol); timeRow.addView(endCol); root.addView(timeRow)

        holiday = CheckBox(this).apply { text = "Feriado o descanso obligatorio"; textSize = 15f; setTextColor(ink); buttonTintList = android.content.res.ColorStateList.valueOf(blue); setPadding(0, dp(5), 0, dp(4)) }
        root.addView(holiday)
        root.addView(fieldLabel("Observaciones (opcional)"))
        notes = EditText(this).apply { hint = "Ej. turno especial, motivo…"; textSize = 15f; minLines = 1; maxLines = 3; setPadding(dp(12), dp(8), dp(12), dp(8)); background = rounded(Color.WHITE, 12); setTextColor(ink) }
        root.addView(notes)

        root.addView(sectionTitle("VISTA PREVIA DE HORAS"))
        val previewRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        preview50 = TextView(this).apply { textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(green); gravity = Gravity.CENTER; setPadding(dp(10), dp(18), dp(10), dp(5)) }
        preview100 = TextView(this).apply { textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(blue); gravity = Gravity.CENTER; setPadding(dp(10), dp(18), dp(10), dp(5)) }
        val card50 = card(paleGreen, preview50, "Horas al 50%", green)
        val card100 = card(paleBlue, preview100, "Horas al 100%", blue)
        previewRow.addView(card50, LinearLayout.LayoutParams(0, dp(110), 1f))
        previewRow.addView(card100, LinearLayout.LayoutParams(0, dp(110), 1f).apply { leftMargin = dp(10) })
        root.addView(previewRow)
        totalPreview = TextView(this).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(navy); gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(8)) }
        root.addView(totalPreview)
        val calc = button("CALCULAR HORAS", blue)
        root.addView(calc)
        val save = button("＋  GUARDAR REGISTRO", navy)
        root.addView(save)

        root.addView(sectionTitle("RESUMEN MENSUAL"))
        monthSummary = TextView(this).apply { textSize = 16f; setTextColor(ink); setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(Color.WHITE, 16) }
        root.addView(monthSummary)
        val historyHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        historyHeader.addView(sectionTitle("HISTORIAL"), LinearLayout.LayoutParams(0, -2, 1f))
        val export = TextView(this).apply { text = "EXPORTAR CSV"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(blue); setPadding(dp(8), dp(12), 0, dp(4)); setOnClickListener { exportCsv() } }
        historyHeader.addView(export)
        root.addView(historyHeader)
        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(history)

        dateField.setOnClickListener { chooseDate() }
        startField.setOnClickListener { chooseTime(startField) }
        endField.setOnClickListener { chooseTime(endField) }
        holiday.setOnCheckedChangeListener { _, _ -> calculate() }
        calc.setOnClickListener { calculate() }
        save.setOnClickListener { saveRecord() }
        setContentView(scroll)
    }

    private fun card(color: Int, amount: TextView, caption: String, accent: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(color, 16); setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(TextView(this@MainActivity).apply { text = caption; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(accent); gravity = Gravity.CENTER })
            addView(amount)
        }
    }
    private fun sectionTitle(s: String) = TextView(this).apply { text = s; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted); setPadding(0, dp(22), 0, dp(10)) }
    private fun fieldLabel(s: String) = TextView(this).apply { text = s; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(muted); setPadding(0, dp(12), 0, dp(3)) }
    private fun pickerField(value: String, hint: String) = TextView(this).apply { text = value.ifBlank { hint }; textSize = 16f; setTextColor(ink); background = rounded(Color.WHITE, 12); setPadding(dp(13), dp(14), dp(13), dp(14)); minimumHeight = dp(48) }
    private fun button(textValue: String, color: Int) = Button(this).apply { text = textValue; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(color); setPadding(dp(6), dp(7), dp(6), dp(7)) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun chooseDate() {
        val c = Calendar.getInstance()
        try { c.time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateField.text.toString())!! } catch (_: Exception) {}
        DatePickerDialog(this, { _, y, m, d ->
            dateField.text = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d); updateDay(); calculate(); refreshMonth()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }
    private fun chooseTime(target: TextView) {
        val parts = target.text.toString().split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: 8; val m = parts.getOrNull(1)?.toIntOrNull() ?: 30
        TimePickerDialog(this, { _, hour, minute -> target.text = String.format(Locale.US, "%02d:%02d", hour, minute); calculate() }, h, m, true).show()
    }
    private fun updateDay() {
        try {
            val c = Calendar.getInstance(); c.time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateField.text.toString())!!
            weekday.text = SimpleDateFormat("EEEE", Locale("es", "EC")).format(c.time).replaceFirstChar { it.uppercase() }
        } catch (_: Exception) { weekday.text = "—" }
    }

    private fun calculate(): Boolean {
        try {
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateField.text.toString())!!
            val cal = Calendar.getInstance().apply { time = date }
            val weekendOrSpecial = holiday.isChecked || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
            val from = parseMinutes(startField.text.toString()); var to = parseMinutes(endField.text.toString())
            if (to <= from) to += 1440
            var mins50 = 0; var mins100 = 0
            for (minuteAbs in from until to) {
                val minute = minuteAbs % 1440
                if (weekendOrSpecial) mins100++
                else if (minute < 360) mins100++ // 00:00–05:59: 100%
                else if (minute >= 1050) mins50++ // from 17:30: 50%
            }
            current50 = mins50 / 60.0; current100 = mins100 / 60.0
            preview50.text = fmt(current50) + " h"
            preview100.text = fmt(current100) + " h"
            totalPreview.text = "TOTAL DE HORAS EXTRAS: ${fmt(current50 + current100)} h"
            return true
        } catch (_: Exception) {
            preview50.text = "—"; preview100.text = "—"; totalPreview.text = "Revisa la fecha y las horas"; return false
        }
    }
    private fun parseMinutes(s: String): Int { val p = s.split(":"); require(p.size == 2); val h = p[0].toInt(); val m = p[1].toInt(); require(h in 0..23 && m in 0..59); return h * 60 + m }
    private fun fmt(n: Double) = String.format(Locale.US, "%.2f", n)

    private fun saveRecord() {
        if (!calculate()) { Toast.makeText(this, "Revisa la fecha y las horas", Toast.LENGTH_SHORT).show(); return }
        val record = JSONObject().put("date", dateField.text.toString()).put("start", startField.text.toString()).put("end", endField.text.toString())
            .put("holiday", holiday.isChecked).put("notes", notes.text.toString()).put("h50", current50).put("h100", current100)
        // Avoid accidentally saving the same date and time twice.
        var duplicate = false
        for (i in 0 until savedRecords.length()) {
            val old = savedRecords.optJSONObject(i) ?: continue
            if (old.optString("date") == record.optString("date") && old.optString("start") == record.optString("start") && old.optString("end") == record.optString("end")) duplicate = true
        }
        if (duplicate) { Toast.makeText(this, "Ese registro ya está guardado", Toast.LENGTH_SHORT).show(); return }
        savedRecords.put(record); persist(); refreshMonth(); Toast.makeText(this, "Registro guardado", Toast.LENGTH_SHORT).show()
    }
    private fun persist() { getPreferences(0).edit().putString("records", savedRecords.toString()).apply() }
    private fun refreshMonth() {
        val month = dateField.text.toString().take(7); var a = 0.0; var b = 0.0; var count = 0
        history.removeAllViews()
        val records = (0 until savedRecords.length()).mapNotNull { savedRecords.optJSONObject(it) }.filter { it.optString("date").startsWith(month) }.sortedBy { it.optString("date") }
        records.forEach { r ->
            a += r.optDouble("h50"); b += r.optDouble("h100"); count++
            val line = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 14); setPadding(dp(14), dp(12), dp(14), dp(12)); setOnLongClickListener { confirmDelete(r); true } }
            line.addView(TextView(this).apply { text = "${r.optString("date")}  ·  ${r.optString("start")}–${r.optString("end")}"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
            line.addView(TextView(this).apply { text = "50%: ${fmt(r.optDouble("h50"))} h     100%: ${fmt(r.optDouble("h100"))} h"; textSize = 14f; setTextColor(muted); setPadding(0, dp(5), 0, 0) })
            if (r.optString("notes").isNotBlank()) line.addView(TextView(this).apply { text = r.optString("notes"); textSize = 13f; setTextColor(muted); setPadding(0, dp(4), 0, 0) })
            history.addView(line, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        monthSummary.text = "Mes: $month\nRegistros: $count\nHoras al 50%: ${fmt(a)} h\nHoras al 100%: ${fmt(b)} h\nTOTAL: ${fmt(a + b)} h\n\nMantén presionado un registro para eliminarlo."
        if (records.isEmpty()) history.addView(TextView(this).apply { text = "Todavía no hay registros para este mes."; textSize = 14f; setTextColor(muted); setPadding(dp(12), dp(8), dp(12), dp(8)) })
    }
    private fun confirmDelete(record: JSONObject) {
        android.app.AlertDialog.Builder(this).setTitle("Eliminar registro").setMessage("¿Deseas eliminar ${record.optString("date")}?")
            .setNegativeButton("Cancelar", null).setPositiveButton("Eliminar") { _, _ ->
                val next = JSONArray(); for (i in 0 until savedRecords.length()) { val r = savedRecords.optJSONObject(i) ?: continue; if (r !== record && !(r.optString("date") == record.optString("date") && r.optString("start") == record.optString("start") && r.optString("end") == record.optString("end"))) next.put(r) }
                savedRecords = next; persist(); refreshMonth()
            }.show()
    }
    private fun exportCsv() {
        if (savedRecords.length() == 0) { Toast.makeText(this, "No hay registros para exportar", Toast.LENGTH_SHORT).show(); return }
        val sb = StringBuilder("Fecha,Entrada,Salida,Feriado o descanso,Observaciones,Horas 50%,Horas 100%,Total\n")
        for (i in 0 until savedRecords.length()) {
            val r = savedRecords.optJSONObject(i) ?: continue
            fun csv(v: String) = "\"${v.replace("\"", "\"\"")}\""
            sb.append(listOf(r.optString("date"), r.optString("start"), r.optString("end"), if (r.optBoolean("holiday")) "Sí" else "No", r.optString("notes"), fmt(r.optDouble("h50")), fmt(r.optDouble("h100")), fmt(r.optDouble("h50") + r.optDouble("h100"))).joinToString(",") { csv(it) }).append('\n')
        }
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/csv"; putExtra(Intent.EXTRA_SUBJECT, "Mis horas extras"); putExtra(Intent.EXTRA_TEXT, sb.toString()) }
        startActivity(Intent.createChooser(intent, "Compartir o guardar CSV"))
    }
}
