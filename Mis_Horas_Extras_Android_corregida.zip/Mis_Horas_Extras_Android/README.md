# Mis Horas Extras — Android

Proyecto Android nativo en Kotlin. La pantalla incluye selección de fecha y horas, casilla para feriado/descanso obligatorio, observaciones, vista previa de horas al 50% y 100%, guardado local, resumen mensual, historial con eliminación y exportación/compartición CSV.

## Reglas de cálculo implementadas
- Lunes a viernes: horas extraordinarias desde las 17:30 se calculan al 50%.
- Franja de 00:00 a 06:00 se calcula al 100%.
- Sábados, domingos, feriados y descanso obligatorio: todas las horas registradas se calculan al 100%.
- Los registros se guardan localmente en el dispositivo.

## Compilar
Abrir la carpeta en Android Studio y ejecutar `assembleDebug` (SDK 35 y Java 17).
